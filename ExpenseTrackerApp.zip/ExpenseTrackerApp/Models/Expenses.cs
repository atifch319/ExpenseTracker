﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ExpenseTrackerApp.Models
{
    public class Expenses
    {
        [Key]
        public int ExpensesId { get; set; }
        [ForeignKey("ExpenseCategory")]
        public int CategoryId { get; set; }
        public double Amount { get; set; }
        public DateTime ExpensesDateTime { get; set; }
        public ExpenseCategories ExpenseCategory { get; set; }
    }
}
