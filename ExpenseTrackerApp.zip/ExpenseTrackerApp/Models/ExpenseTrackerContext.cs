﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExpenseTrackerApp.Models
{
    public class ExpenseTrackerContext : DbContext
    {
        public ExpenseTrackerContext(DbContextOptions<ExpenseTrackerContext> options) : base(options)
        {

        }
        public DbSet<ExpenseCategories> ExpenseCategories { get;set;}
        public DbSet<Expenses> Expenses { get;set;}
    }
}
