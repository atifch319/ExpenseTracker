﻿using ExpenseTrackerApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace ExpenseTrackerApp.Controllers
{
    public class ExpenseCategoryController : Controller
    {
        private readonly ExpenseTrackerContext _context;

        public ExpenseCategoryController(ExpenseTrackerContext context)
        {
            _context = context;
        }

        // GET: ExpenseTracker
        public async Task<IActionResult> Index()
        {
            return View(await _context.ExpenseCategories.ToListAsync());
        }

        // GET: ExpenseTracker/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var expenseCategories = await _context.ExpenseCategories
                .FirstOrDefaultAsync(m => m.CategoryId == id);
            if (expenseCategories == null)
            {
                return NotFound();
            }

            return View(expenseCategories);
        }

        // GET: ExpenseTracker/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: ExpenseTracker/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CategoryId,CategoryName,CreatedDateTime")] ExpenseCategories expenseCategories)
        {
            expenseCategories.CreatedDateTime = DateTime.Now;
            if (ModelState.IsValid)
            {
                var isExist = _context.ExpenseCategories.Any(c => c.CategoryName.ToLower() == expenseCategories.CategoryName.ToLower());
                if (isExist)
                {
                    TempData["ValidateMsg"] = "Error: Record name already exists!";
                    return RedirectToAction(nameof(Create));
                }
                _context.Add(expenseCategories);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(expenseCategories);
        }

        // GET: ExpenseTracker/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var expenseCategories = await _context.ExpenseCategories.FindAsync(id);
            if (expenseCategories == null)
            {
                return NotFound();
            }
            return View(expenseCategories);
        }

        // POST: ExpenseTracker/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CategoryId,CategoryName,CreatedDateTime")] ExpenseCategories expenseCategories)
        {
            if (id != expenseCategories.CategoryId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(expenseCategories);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ExpenseCategoriesExists(expenseCategories.CategoryId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(expenseCategories);
        }

        // GET: ExpenseTracker/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var expenseCategories = await _context.ExpenseCategories
                .FirstOrDefaultAsync(m => m.CategoryId == id);
            if (expenseCategories == null)
            {
                return NotFound();
            }

            return View(expenseCategories);
        }

        // POST: ExpenseTracker/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var expenseCategories = await _context.ExpenseCategories.FindAsync(id);
            _context.ExpenseCategories.Remove(expenseCategories);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ExpenseCategoriesExists(int id)
        {
            return _context.ExpenseCategories.Any(e => e.CategoryId == id);
        }
    }
}
