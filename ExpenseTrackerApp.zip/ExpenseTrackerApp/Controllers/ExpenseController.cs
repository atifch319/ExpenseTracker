﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ExpenseTrackerApp.Models;

namespace ExpenseTrackerApp.Controllers
{
    public class ExpenseController : Controller
    {
        private readonly ExpenseTrackerContext _context;

        public ExpenseController(ExpenseTrackerContext context)
        {
            _context = context;
        }

        // GET: Expense
        public async Task<IActionResult> Index(DateTime? FromDate, DateTime? ToDate)
        {
            var expenseTrackerContext = _context.Expenses.Include(e => e.ExpenseCategory).AsQueryable();
            var filter = "";
            if (FromDate.HasValue)
            {
                filter = "Filter by: " + FromDate.Value.ToString("dd-MMM-yyyy");
                expenseTrackerContext = expenseTrackerContext.Where(c => c.ExpensesDateTime >= FromDate);
            }
            if (ToDate.HasValue)
            {
                filter += "  To  " + ToDate.Value.ToString("dd-MMM-yyyy");
                ToDate = ToDate.Value.AddDays(1).AddMilliseconds(-3);
                expenseTrackerContext = expenseTrackerContext.Where(c => c.ExpensesDateTime <= ToDate);
            }

            ViewBag.SearchFilter = filter;
            return View(await expenseTrackerContext.ToListAsync());
        }

        // GET: Expense/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var expenses = await _context.Expenses
                .Include(e => e.ExpenseCategory)
                .FirstOrDefaultAsync(m => m.ExpensesId == id);
            if (expenses == null)
            {
                return NotFound();
            }

            return View(expenses);
        }

        // GET: Expense/Create
        public IActionResult Create()
        {
            ViewBag.maxDate = DateTime.Now.AddDays(1).ToString("yyyy-MM-dd HH:mm");
            var categories = _context.ExpenseCategories.ToList();
            ViewBag.Categories = categories;
            return View();
        }

        // POST: Expense/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ExpensesId,CategoryId,Amount,ExpensesDateTime")] Expenses expenses)
        {
            if (ModelState.IsValid)
            {
                _context.Add(expenses);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            var categories = _context.ExpenseCategories.ToList();
            ViewBag.Categories = categories;
            return View(expenses);
        }

        // GET: Expense/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var expenses = await _context.Expenses.FindAsync(id);
            if (expenses == null)
            {
                return NotFound();
            }
            ViewBag.maxDate = DateTime.Now.AddDays(1).ToString("yyyy-MM-dd HH:mm");
            var categories = _context.ExpenseCategories.ToList();
            ViewBag.Categories = categories;
            return View(expenses);
        }

        // POST: Expense/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ExpensesId,CategoryId,Amount,ExpensesDateTime")] Expenses expenses)
        {
            if (id != expenses.ExpensesId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(expenses);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ExpensesExists(expenses.ExpensesId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            var categories = _context.ExpenseCategories.ToList();
            ViewBag.Categories = categories;
            return View(expenses);
        }

        // GET: Expense/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var expenses = await _context.Expenses
                .Include(e => e.ExpenseCategory)
                .FirstOrDefaultAsync(m => m.ExpensesId == id);
            if (expenses == null)
            {
                return NotFound();
            }

            return View(expenses);
        }

        // POST: Expense/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var expenses = await _context.Expenses.FindAsync(id);
            _context.Expenses.Remove(expenses);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ExpensesExists(int id)
        {
            return _context.Expenses.Any(e => e.ExpensesId == id);
        }
    }
}
