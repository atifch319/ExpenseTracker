﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ExpenseTrackerApp.Migrations
{
    public partial class connectionstring : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
